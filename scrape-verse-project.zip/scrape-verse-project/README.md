# Self-Healing Scraper Kit — Into the Scrape-Verse Hackathon

A reusable pipeline built on **Bright Data Scraper Studio** (`bdata` CLI) that turns any
public website into structured JSON, keeps working when the site changes, and ships
with a tiny dashboard to view results.

## What this does

1. **Create** — generates a scraper from a URL + plain-English description (AI-powered).
2. **Run** — executes it and saves timestamped JSON to `data/`.
3. **Heal** — when the target site changes and the scraper breaks, describe what broke
   and Scraper Studio proposes a fix.
4. **Approve** — accept or reject the fix, no downstream code touched.
5. **View** — `viewer/index.html` renders the latest JSON as a simple table.

## Why this project (long-tail pick)

Point it at a niche or regional site that doesn't already have one of Bright Data's
800+ pre-built scrapers — a documentation site, a regional e-commerce catalog, or a
competitor's changelog page. That's the target this kit is built for.

## Setup

```bash
# 1. Run the Bright Data CLI without a global install
npx -p @brightdata/cli bdata login

# 2. Point the pipeline at your target
./scripts/run-pipeline.sh "https://example.com/target-page" "title, price, url"
```

## Files

- `scripts/run-pipeline.sh` — orchestrates create → run, saves output to `data/`
- `scripts/heal-demo.sh` — breaks-and-fixes demo for your video (heal → approve)
- `viewer/index.html` — open in a browser after a run to see results as a table
- `prompts/create-prompt.md` — example prompts to hand the CLI or a coding agent
- `SUBMISSION.md` — drop-in text for the hackathon submission form

## How Scraper Studio was used

Scraper Studio generated the extraction logic from a URL + description (no manual
selectors written), handled proxy rotation/CAPTCHA/rendering, and its `heal` command
regenerated the scraper after a live site change — verified in `scripts/heal-demo.sh`
and the demo video.

## License

MIT — see `LICENSE`.
