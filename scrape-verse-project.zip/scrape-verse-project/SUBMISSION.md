# Submission text (fill in the [brackets], then paste into the form)

## Project title
Self-Healing Scraper Kit for [target site / domain]

## Project description
[Target site] doesn't have one of Bright Data's 800+ pre-built scrapers, so I built a
reusable pipeline on top of Scraper Studio's CLI that turns it into structured JSON,
recovers automatically when the site's layout changes, and ships with a lightweight
dashboard so the output is usable immediately — not just a JSON dump.

The pipeline: `create` generates the scraper from a URL and a plain-English field
list, `run` saves timestamped JSON to `data/`, and when I broke the scraper on
purpose (renamed a CSS class / changed pagination) `heal` regenerated a working
version from a one-line description of what broke — same Collector ID, no downstream
code touched. `viewer/index.html` renders the latest run as a table.

## How Scraper Studio was used
- `bdata scraper create` generated the extraction logic from a URL + description —
  no manual selectors.
- Scraper Studio handled proxy rotation, browser rendering, and CAPTCHA solving
  behind the Collector ID.
- `bdata scraper heal` + `bdata scraper approve` recovered the scraper after a live
  site change, demonstrated in the video at [timestamp].

## Tech stack
Bright Data Scraper Studio (`bdata` CLI), Bash, vanilla HTML/JS dashboard.

## Repo
[your GitHub URL after you push this]

## Demo video
[your video URL]
