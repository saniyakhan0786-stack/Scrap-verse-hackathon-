#!/usr/bin/env bash
# Demonstrates the self-healing loop for your demo video.
# Usage: ./heal-demo.sh "<what broke, e.g. 'site redesigned, prices moved to a new class'>"
set -euo pipefail

DESCRIPTION="${1:?Usage: heal-demo.sh \"<what broke>\"}"
DATA_DIR="$(dirname "$0")/../data"
COLLECTOR_ID=$(cat "$DATA_DIR/.last_collector_id" 2>/dev/null || true)

if [ -z "$COLLECTOR_ID" ]; then
  echo "No saved Collector ID found. Run run-pipeline.sh first, or pass one manually:"
  echo "  npx -p @brightdata/cli bdata scraper heal <COLLECTOR_ID> \"$DESCRIPTION\""
  exit 1
fi

echo "==> Healing collector $COLLECTOR_ID"
npx -p @brightdata/cli bdata scraper heal "$COLLECTOR_ID" "$DESCRIPTION"

echo ""
echo "==> Review the proposed fix above, then either:"
echo "    Approve: npx -p @brightdata/cli bdata scraper approve $COLLECTOR_ID"
echo "    Reject:  npx -p @brightdata/cli bdata scraper approve $COLLECTOR_ID --reject"
