#!/usr/bin/env bash
# Usage: ./run-pipeline.sh "<URL>" "<data you need, comma separated>"
set -euo pipefail

URL="${1:?Usage: run-pipeline.sh <URL> \"<data you need>\"}"
DATA_DESC="${2:?Usage: run-pipeline.sh <URL> \"<data you need>\"}"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
DATA_DIR="$(dirname "$0")/../data"

echo "==> Creating scraper for: $URL"
CREATE_OUTPUT=$(npx -p @brightdata/cli bdata scraper create "$URL" "$DATA_DESC")
echo "$CREATE_OUTPUT"

COLLECTOR_ID=$(echo "$CREATE_OUTPUT" | grep -oE 'c_[a-zA-Z0-9]+' | head -1)
if [ -z "$COLLECTOR_ID" ]; then
  echo "Could not parse Collector ID from output above. Copy it manually and run:"
  echo "  npx -p @brightdata/cli bdata scraper run <COLLECTOR_ID> $URL"
  exit 1
fi
echo "==> Collector ID: $COLLECTOR_ID"
echo "$COLLECTOR_ID" > "$DATA_DIR/.last_collector_id"

echo "==> Running scraper"
RESULT_FILE="$DATA_DIR/result-$TIMESTAMP.json"
npx -p @brightdata/cli bdata scraper run "$COLLECTOR_ID" "$URL" > "$RESULT_FILE"
cp "$RESULT_FILE" "$DATA_DIR/latest.json"

echo "==> Saved: $RESULT_FILE"
echo "==> Open viewer/index.html in a browser to see the results table."
