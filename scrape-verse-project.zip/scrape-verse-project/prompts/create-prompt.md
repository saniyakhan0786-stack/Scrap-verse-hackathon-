# Example prompts

Use these with `bdata scraper create <URL> "<prompt>"` or paste into a coding agent
(Claude Code, Cursor, Codex) along with this repo for context.

## Discovery / listing page
> "Extract every item title, price, product URL, and rating from this listing page.
> Return one JSON object per item."

## Documentation / changelog page (Sitemap type)
> "Crawl this docs site's sitemap and extract page title, URL, last-updated date, and
> the full page text as one JSON object per page."

## Competitor changelog (weekly diff pipeline)
> "Extract every changelog entry's date, title, and summary from this page. I'll diff
> this against last week's run to catch new entries."

## Healing prompt (after a real or simulated site change)
> "The site redesigned — [describe what changed, e.g. 'prices moved from `.price` to
> `.product-cost`, and pagination is now infinite-scroll instead of numbered pages'].
> Fix the scraper to match the new structure without changing the output schema."

## Tips for a strong prompt
- Name the exact fields you want, not "get all the data."
- Mention the output shape you expect (one row per item / one row per page).
- For the heal prompt, describe the *symptom* (empty fields, wrong values) and the
  *cause* if you know it (renamed class, new layout) — both help the fix.
